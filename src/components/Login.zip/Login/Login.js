import { Avatar, Button, Container, CssBaseline, FormControlLabel, Grid, makeStyles, TextField, Typography } from '@material-ui/core';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import React from 'react';
// import firebase, { auth } from 'firebase';
import { useState } from 'react';
import { Link, useHistory, useLocation } from 'react-router-dom';
import googleIcon from "../../Images/google-icon.svg";
import "./Login.css";
import { Controller, useForm } from "react-hook-form";
// import firebaseConfig from '../../FirebaseConfig';
import { useContext } from 'react';
import { UserContext } from '../../App';
import { initializeFirebaseFramework } from './LoginManager';



// if (firebase.apps.length === 0) { firebase.initializeApp(firebaseConfig) }


const Login = () => {

    // Initialize firebase
    initializeFirebaseFramework();

    const [loggedInUser, setLoggedInUser] = useContext(UserContext);
    const [user, setUser] = useState({});

    // useState for login/Register Toggle
    const [isRegistered, setRegistered] = useState(false);
    const history = useHistory();
    const location = useLocation();
    const { from } = location.state || { from: { pathname: "/" } };
    const handleRegister = () => {
        setRegistered(!isRegistered)
        user.error = "";
    };
    // const googleProvider = new firebase.auth.GoogleAuthProvider();
    // react Hook Form

    const updateName = name => {
        const user = firebase.auth().currentUser;
        user.updateProfile({
            displayName: name,
        })
            .then(() => { })
            .catch(error => {

            });
    }

    const { register, handleSubmit, control } = useForm();
    const onSubmit = data => {
        const { email, password } = data;
        if (isRegistered && email && password) {
            firebase.auth().createUserWithEmailAndPassword(email, password)
                .then((userCredential) => {
                    const signedUser = { ...user };
                    signedUser.success = true;
                    signedUser.error = "";
                    updateName(user.name);
                    setUser(signedUser);
                    setLoggedInUser(signedUser);
                    history.replace(from);

                })
                .catch((error) => {
                    var errorMessage = error.message;
                    const notSignedIn = {};
                    notSignedIn.error = errorMessage;
                    setUser(notSignedIn);
                    setLoggedInUser(notSignedIn);
                });
        }
        if (!isRegistered && email && password) {
            firebase.auth().signInWithEmailAndPassword(email, password)
                .then((userCredential) => {
                    // Signed in
                    const { displayName, email } = userCredential.user;

                    const verifiedUser = {};
                    verifiedUser.name = displayName;
                    verifiedUser.email = email;
                    verifiedUser.success = true;
                    verifiedUser.error = "";
                    setUser(verifiedUser);
                    setLoggedInUser(verifiedUser);
                    history.replace(from);



                })
                .catch((error) => {
                    var errorMessage = error.message;
                    const verifiedUser = {};
                    verifiedUser.error = errorMessage;
                    setUser(verifiedUser)
                });
        }

        return false;
    }
    // Handle user Input
    const handleInput = e => {
        let isValid = true;

        if (e.target.name === "email") {
            isValid = /\S+@\S+\.\S+/.test(e.target.value);
        }

        if (e.target.name === "password") {
            isValid = /^[a-zA-Z0-9]{8,}$/.test(e.target.value);
        }
        if (isValid) {
            const newUser = { ...user };
            newUser[e.target.name] = e.target.value;
            newUser["error_" + e.target.name] = false;
            setUser(newUser)
        } else if (!isValid) {
            const newUser = { ...user };
            newUser["error_" + e.target.name] = true;
            setUser(newUser)
        }

    }

    //Google Sign In

    // const handleGoogleSignIn = () => {
    //     firebase.auth().signInWithPopup(googleProvider).then(res => {
    //         const { displayName, email } = res.user;
    //         const getGoogleUser = {
    //             name: displayName,
    //             email: email,
    //             success: true,
    //             error: "",
    //             error_email: "",
    //             error_password: "",
    //         }
    //         setUser(getGoogleUser)
    //         setLoggedInUser(getGoogleUser)
    //         history.replace(from);
    //     })
    // }



    const useStyles = makeStyles((theme) => ({
        paper: {
            marginTop: theme.spacing(8),
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
        },
        avatar: {
            margin: theme.spacing(1),
            backgroundColor: theme.palette.secondary.main,
        },
        form: {
            width: '100%', // Fix IE 11 issue.
            marginTop: theme.spacing(3),
        },
        submit: {
            margin: theme.spacing(3, 0, 2),
        },
    }));
    const classes = useStyles();
    return (
        <div>

            <Container className="LoginContainer" style={{ background: 'hsla(0, 0%, 100%, 0.5)' }} component="main" maxWidth="xs">
                <CssBaseline />
                <div className={classes.paper}>
                    <Avatar className={classes.avatar}> <LockOutlinedIcon /> </Avatar>
                    <Typography component="h1" variant="h5"> {!isRegistered ? "Sign In" : "Sign Up"} </Typography>
                    {user.error ? <p className="validationError" style={{ color: "red" }}>{user.error}</p> : <p className="validationError" style={{ color: "green" }}>{loggedInUser.success}</p>}

                    <form className={classes.form} onSubmit={handleSubmit(onSubmit)}>
                        <Grid container spacing={2}>
                            {isRegistered &&
                                <Grid item xs={12}>
                                    <Controller
                                        name="name"
                                        // onBlur={handleInput}
                                        as={
                                            <TextField autoComplete="fname" ref={register} variant="outlined" required fullWidth id="firstName" label="Name" autoFocus />
                                        } onKeyUp={handleInput} control={control} />
                                </Grid>
                            }

                            <Grid item xs={12}>
                                <Controller
                                    name="email"

                                    as={
                                        <TextField variant="outlined" required fullWidth id="email" default="" label="Email Address" />
                                    } onKeyUp={handleInput} control={control} />
                                {user.error_email ? <span style={{ color: "red" }}>Invalid Email</span> : ""}
                            </Grid>

                            <Grid item xs={12}>
                                <Controller
                                    name="password"

                                    as={
                                        <TextField variant="outlined" required fullWidth label="Password" type="password" id="password" autoComplete="current-password" />
                                    } onKeyUp={handleInput} control={control} />
                                {user.error_password ? <span style={{ color: "red" }}>Invalid Password [Minimum: 8 digits]</span> : ""}
                            </Grid>



                        </Grid>
                        <Button type="submit" fullWidth variant="contained" color="primary" className={classes.submit}> {!isRegistered ? "Sign In" : "Sign Up"}  </Button>
                        <Grid container justify="flex-end">
                            <Grid item>
                                <Link className="LoginUpLink" href="#" onClick={handleRegister} variant="body2">  {isRegistered ? "Having an account? Sign In" : "New User! Sign Up"} </Link>
                            </Grid>
                        </Grid>
                    </form>
                </div>
            </Container>
            <div className="devider"> <div></div><strong>Or</strong><div></div></div>
            <div className="LogInGoogle">
                <button onClick={handleGoogleSignIn}> <img src={googleIcon} height="20px" alt="" /> <p>Continue With Google</p></button>
            </div>
        </div >

    );
};

export default Login;