import firebase, { auth } from 'firebase';
import firebaseConfig from '../../FirebaseConfig';

export const initializeFirebaseFramework = () => {
    if (firebase.apps.length === 0) { firebase.initializeApp(firebaseConfig) }
}


export const handleGoogleSignIn = () => {
    const googleProvider = new firebase.auth.GoogleAuthProvider();
    return firebase.auth()
        .signInWithPopup(googleProvider)
        .then(res => {
            const { displayName, email } = res.user;
            const getGoogleUser = {
                name: displayName,
                email: email,
                success: true,
                error: "",
                error_email: "",
                error_password: "",
            }
            // setUser(getGoogleUser)
            // setLoggedInUser(getGoogleUser)
            // history.replace(from);

            return getGoogleUser;
        })
}